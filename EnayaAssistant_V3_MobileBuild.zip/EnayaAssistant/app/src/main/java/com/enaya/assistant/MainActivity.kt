package com.enaya.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.enaya.assistant.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity(), RecognitionListener, TextToSpeech.OnInitListener {
    private lateinit var binding: ActivityMainBinding
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var listening = false
    private var continuous = false
    private var pending: Pair<ContactMatch, EnayaCommand>? = null
    private lateinit var executor: CommandExecutor

    private val permissionsLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasPermissions()) startListening() else status("Microphone, Contacts ও Phone permission Allow করুন")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        executor = CommandExecutor(this)
        tts = TextToSpeech(this, this)
        setupRecognizer()
        binding.speakButton.setOnClickListener { requestAndListen() }
        binding.continuousSwitch.setOnCheckedChangeListener { _, checked ->
            continuous = checked
            if (checked) requestAndListen() else {
                recognizer?.cancel(); listening = false; updateUi(false); status("Continuous listening বন্ধ")
            }
        }
        binding.confirmButton.setOnClickListener { pending?.let { performContactAction(it.first, it.second) } }
        binding.cancelButton.setOnClickListener { clearPending("কাজটি বাতিল করা হয়েছে") }
        binding.helpButton.setOnClickListener { showHelp() }
        status("TAP TO SPEAK চাপুন, অথবা Continuous mode চালু করুন")
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status("Google Speech Services ইনস্টল/সক্রিয় নেই")
            binding.speakButton.isEnabled = false
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
    }

    private fun hasPermissions() = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.CAMERA)
        .all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }

    private fun requestAndListen() {
        if (!hasPermissions()) permissionsLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.CAMERA))
        else startListening()
    }

    private fun startListening() {
        if (listening) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }
        try {
            recognizer?.startListening(intent)
            listening = true; updateUi(true); status("বলুন… Hey Enaya, Rafi কে কল দাও")
        } catch (e: Exception) { listening = false; updateUi(false); status("মাইক্রোফোন চালু হয়নি: ${e.message}") }
    }

    private fun handle(text: String) {
        binding.heardText.text = "শুনেছি: “$text”"
        pending?.let { p ->
            when {
                VoiceCommandParser.isYes(text) -> performContactAction(p.first, p.second)
                VoiceCommandParser.isNo(text) -> clearPending("বাতিল করা হয়েছে")
                else -> status("হ্যাঁ বা না বলুন")
            }
            return
        }

        val command = VoiceCommandParser.parse(text)
        when (command) {
            is EnayaCommand.Call -> resolveContact(command.name, command)
            is EnayaCommand.Sms -> resolveContact(command.name, command)
            is EnayaCommand.WhatsApp -> resolveContact(command.name, command)
            EnayaCommand.Help -> showHelp()
            EnayaCommand.Unknown -> say("কমান্ড বুঝিনি। HELP চাপলে উদাহরণ দেখবেন")
            else -> say(executor.execute(command))
        }
    }

    private fun resolveContact(name: String, command: EnayaCommand) {
        val match = ContactRepository(this).findBestMatch(name)
        if (match == null) { say("$name নামে কোনো কন্টাক্ট পাওয়া যায়নি"); return }
        pending = match to command
        binding.contactName.text = match.name
        binding.contactNumber.text = match.number
        binding.confirmPanel.visibility = View.VISIBLE
        val action = when (command) { is EnayaCommand.Call -> "কল"; is EnayaCommand.Sms -> "SMS"; else -> "WhatsApp" }
        say("${match.name} কে $action করবেন?")
    }

    private fun performContactAction(contact: ContactMatch, command: EnayaCommand) {
        val result = when (command) {
            is EnayaCommand.Call -> if (CallManager.call(this, contact.number)) "${contact.name} কে কল করা হচ্ছে" else "Phone permission নেই"
            is EnayaCommand.Sms -> executor.composeSms(contact.number, command.message)
            is EnayaCommand.WhatsApp -> executor.openWhatsApp(contact.number, command.message)
            else -> "কাজটি করা যায়নি"
        }
        clearPending(result)
    }

    private fun clearPending(message: String) { pending = null; binding.confirmPanel.visibility = View.GONE; say(message) }

    private fun showHelp() {
        binding.helpPanel.visibility = if (binding.helpPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        say("কমান্ড তালিকা দেখানো হয়েছে")
    }

    private fun say(message: String) {
        status(message)
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "enaya")
    }

    private fun status(message: String) { binding.statusText.text = message }
    private fun updateUi(on: Boolean) {
        binding.speakButton.text = if (on) "LISTENING…" else "TAP TO SPEAK"
        binding.speakButton.isEnabled = !on
        binding.orbGlow.alpha = if (on) 1f else .65f
    }
    private fun restartIfNeeded() { if (continuous && !isFinishing) binding.root.postDelayed({ startListening() }, 700) }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val bn = Locale("bn", "BD")
            if ((tts?.isLanguageAvailable(bn) ?: -1) >= TextToSpeech.LANG_AVAILABLE) tts?.language = bn else tts?.language = Locale.US
        }
    }
    override fun onReadyForSpeech(params: Bundle?) { status("আপনার কথা শুনছি…") }
    override fun onBeginningOfSpeech() { status("শুনছি…") }
    override fun onRmsChanged(rmsdB: Float) { binding.orbGlow.scaleX = 1f + (rmsdB.coerceAtLeast(0f) / 70f); binding.orbGlow.scaleY = binding.orbGlow.scaleX }
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() { status("প্রসেস করছি…") }
    override fun onError(error: Int) {
        listening = false; updateUi(false)
        val msg = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH -> "কথা বুঝতে পারিনি"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কোনো কথা শোনা যায়নি"
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "ইন্টারনেট বা Google Speech Service সমস্যা"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission দিন"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "মাইক্রোফোন ব্যস্ত"
            else -> "Voice error: $error"
        }
        status(msg); restartIfNeeded()
    }
    override fun onResults(results: Bundle?) {
        listening = false; updateUi(false)
        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val best = list.firstOrNull { VoiceCommandParser.parse(it) !is EnayaCommand.Unknown } ?: list.firstOrNull()
        if (best.isNullOrBlank()) status("কিছু শোনা যায়নি") else handle(best)
        restartIfNeeded()
    }
    override fun onPartialResults(partialResults: Bundle?) {
        partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { binding.heardText.text = "শুনছি: “$it”" }
    }
    override fun onEvent(eventType: Int, params: Bundle?) = Unit
    override fun onDestroy() { continuous = false; recognizer?.destroy(); tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
