package com.enaya.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CommandExecutor(private val activity: Activity) {
    fun execute(command: EnayaCommand): String = when (command) {
        EnayaCommand.Camera -> launch(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "ক্যামেরা খোলা হচ্ছে")
        is EnayaCommand.Flashlight -> flashlight(command.enabled)
        is EnayaCommand.OpenApp -> openApp(command.app)
        is EnayaCommand.WebSearch -> launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${enc(command.query)}")), "Google-এ খোঁজা হচ্ছে")
        is EnayaCommand.YouTubeSearch -> launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${enc(command.query)}")), "YouTube-এ খোঁজা হচ্ছে")
        EnayaCommand.Settings -> launch(Intent(Settings.ACTION_SETTINGS), "Settings খোলা হচ্ছে")
        EnayaCommand.Battery -> {
            val bm = activity.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            "ব্যাটারি ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} শতাংশ"
        }
        EnayaCommand.Time -> "এখন ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}"
        EnayaCommand.Date -> "আজ ${SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())}"
        else -> ""
    }

    fun composeSms(number: String, message: String?): String {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", message ?: "")
        return launch(i, "SMS খোলা হচ্ছে")
    }

    fun openWhatsApp(number: String, message: String?): String {
        val clean = number.filter { it.isDigit() }.let { if (it.startsWith("0")) "88$it" else it }
        val uri = Uri.parse("https://wa.me/$clean?text=${enc(message ?: "")}")
        return launch(Intent(Intent.ACTION_VIEW, uri), "WhatsApp খোলা হচ্ছে")
    }

    private fun openApp(name: String): String {
        val aliases = mapOf(
            "facebook" to "com.facebook.katana", "ফেসবুক" to "com.facebook.katana",
            "messenger" to "com.facebook.orca", "মেসেঞ্জার" to "com.facebook.orca",
            "youtube" to "com.google.android.youtube", "ইউটিউব" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp", "হোয়াটসঅ্যাপ" to "com.whatsapp", "হোয়াটসঅ্যাপ" to "com.whatsapp",
            "chrome" to "com.android.chrome", "ক্রোম" to "com.android.chrome",
            "gmail" to "com.google.android.gm", "জিমেইল" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps", "ম্যাপ" to "com.google.android.apps.maps",
            "play store" to "com.android.vending", "প্লে স্টোর" to "com.android.vending"
        )
        val pkg = aliases.entries.firstOrNull { name.contains(it.key, true) }?.value
        if (pkg != null) {
            val intent = activity.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) return launch(intent, "$name খোলা হচ্ছে")
        }
        return launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${enc(name + " app")}")), "$name ইনস্টল নেই—Google search খোলা হচ্ছে")
    }

    private fun flashlight(on: Boolean): String = try {
        val cm = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return "এই ফোনে flashlight পাওয়া যায়নি"
        cm.setTorchMode(id, on)
        if (on) "ফ্ল্যাশলাইট চালু হয়েছে" else "ফ্ল্যাশলাইট বন্ধ হয়েছে"
    } catch (e: Exception) { "ফ্ল্যাশলাইট নিয়ন্ত্রণ করা যায়নি" }

    private fun launch(intent: Intent, ok: String): String = try { activity.startActivity(intent); ok } catch (e: Exception) { "এই কাজের জন্য উপযুক্ত অ্যাপ পাওয়া যায়নি" }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
