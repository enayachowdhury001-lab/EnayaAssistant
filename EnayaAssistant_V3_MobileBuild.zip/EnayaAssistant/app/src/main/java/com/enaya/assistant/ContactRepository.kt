package com.enaya.assistant

import android.content.Context
import android.provider.ContactsContract

data class ContactMatch(val name: String, val number: String)

class ContactRepository(private val context: Context) {
    fun findBestMatch(query: String): ContactMatch? {
        val normalizedQuery = normalize(query)
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        val contacts = mutableListOf<ContactMatch>()
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            null,
            null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
        )?.use { cursor ->
            val nameIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameIndex) ?: continue
                val number = cursor.getString(numberIndex) ?: continue
                contacts += ContactMatch(name, number)
            }
        }

        return contacts.firstOrNull { normalize(it.name) == normalizedQuery }
            ?: contacts.firstOrNull { normalize(it.name).startsWith(normalizedQuery) }
            ?: contacts.firstOrNull { normalize(it.name).contains(normalizedQuery) }
    }

    private fun normalize(value: String): String = value.lowercase()
        .replace(Regex("[^a-z0-9অ-হঀ-৿ ]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
}
