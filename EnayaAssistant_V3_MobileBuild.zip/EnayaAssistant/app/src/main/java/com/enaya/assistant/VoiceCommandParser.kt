package com.enaya.assistant

sealed class EnayaCommand {
    data class Call(val name: String) : EnayaCommand()
    data class OpenApp(val app: String) : EnayaCommand()
    data class WebSearch(val query: String) : EnayaCommand()
    data class YouTubeSearch(val query: String) : EnayaCommand()
    data class Sms(val name: String, val message: String?) : EnayaCommand()
    data class WhatsApp(val name: String, val message: String?) : EnayaCommand()
    data object Camera : EnayaCommand()
    data class Flashlight(val enabled: Boolean) : EnayaCommand()
    data object Battery : EnayaCommand()
    data object Time : EnayaCommand()
    data object Date : EnayaCommand()
    data object Settings : EnayaCommand()
    data object Help : EnayaCommand()
    data object Unknown : EnayaCommand()
}

object VoiceCommandParser {
    private val wake = Regex("(?i)\\b(hey|hi)\\s+enaya\\b|হেই\\s*এনায়া|হে\\s*এনায়া|এনায়া")

    fun parse(raw: String): EnayaCommand {
        val text = normalize(raw.replace(wake, " "))

        if (containsAny(text, "help", "commands", "কি করতে পারো", "কমান্ড")) return EnayaCommand.Help
        if (containsAny(text, "battery", "চার্জ", "ব্যাটারি")) return EnayaCommand.Battery
        if (containsAny(text, "what time", "time", "কয়টা বাজে", "কয়টা বাজে", "সময়")) return EnayaCommand.Time
        if (containsAny(text, "date", "আজ কত তারিখ", "তারিখ")) return EnayaCommand.Date
        if (containsAny(text, "open settings", "settings খোলো", "সেটিংস খোলো")) return EnayaCommand.Settings
        if (containsAny(text, "open camera", "camera খোলো", "ক্যামেরা খোলো")) return EnayaCommand.Camera
        if (containsAny(text, "flashlight on", "torch on", "ফ্ল্যাশলাইট চালু", "টর্চ চালু", "লাইট চালু")) return EnayaCommand.Flashlight(true)
        if (containsAny(text, "flashlight off", "torch off", "ফ্ল্যাশলাইট বন্ধ", "টর্চ বন্ধ", "লাইট বন্ধ")) return EnayaCommand.Flashlight(false)

        Regex("(?i)(?:search|google)\\s+(.+)").find(text)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }?.let {
            return EnayaCommand.WebSearch(it)
        }
        Regex("(?:সার্চ করো|গুগলে খোঁজো|গুগলে খুঁজো)\\s+(.+)").find(text)?.groupValues?.getOrNull(1)?.trim()?.let {
            return EnayaCommand.WebSearch(it)
        }
        Regex("(?i)(?:youtube|ইউটিউব)(?:ে)?\\s+(?:search\\s+|সার্চ\\s+)?(.+)").find(text)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }?.let {
            return EnayaCommand.YouTubeSearch(it)
        }

        parseMessage(text, whatsapp = true)?.let { return it }
        parseMessage(text, whatsapp = false)?.let { return it }

        Regex("(?i)(?:call|calling|phone)\\s+(.+)").find(text)?.groupValues?.getOrNull(1)?.let { cleanName(it) }?.let {
            return EnayaCommand.Call(it)
        }
        Regex("(.+?)(?:কে|কো)?\\s*(?:কল|ফোন)\\s*(?:দাও|করো|কর)?$").find(text)?.groupValues?.getOrNull(1)?.let { cleanName(it) }?.let {
            return EnayaCommand.Call(it)
        }

        Regex("(?i)(?:open|launch)\\s+(.+)").find(text)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }?.let {
            return EnayaCommand.OpenApp(it)
        }
        Regex("(.+?)\\s*(?:খোলো|চালু করো|ওপেন করো)$").find(text)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }?.let {
            return EnayaCommand.OpenApp(it)
        }

        return EnayaCommand.Unknown
    }

    private fun parseMessage(text: String, whatsapp: Boolean): EnayaCommand? {
        val channel = if (whatsapp) "(?:whatsapp|হোয়াটসঅ্যাপ|হোয়াটসঅ্যাপ)" else "(?:sms|message|মেসেজ|এসএমএস)"
        val regex = Regex("(?i)$channel\\s+(?:to\\s+)?(.+?)(?:\\s+(?:saying|say|বলে|লিখে)\\s+(.+))?$")
        val m = regex.find(text) ?: return null
        val name = cleanName(m.groupValues[1]) ?: return null
        val msg = m.groupValues.getOrNull(2)?.trim()?.takeIf { it.isNotBlank() }
        return if (whatsapp) EnayaCommand.WhatsApp(name, msg) else EnayaCommand.Sms(name, msg)
    }

    fun isYes(raw: String) = containsAny(normalize(raw), "yes", "yeah", "confirm", "হ্যাঁ", "হ্যা", "জি", "করো", "দাও")
    fun isNo(raw: String) = containsAny(normalize(raw), "no", "cancel", "stop", "না", "বাতিল", "থামো")

    private fun cleanName(v: String): String? = v
        .replace(Regex("(?i)\\b(please|now|to)\\b|দয়া করে|দয়া করে|কল দাও|কল করো|ফোন দাও|ফোন করো"), " ")
        .replace(Regex("\\s+(কে|কো)$"), "")
        .replace(Regex("\\s+"), " ").trim().takeIf { it.length >= 2 }

    private fun containsAny(text: String, vararg terms: String) = terms.any { text.contains(it, true) }
    private fun normalize(text: String) = text.lowercase().replace(Regex("[^a-z0-9অ-হঀ-৿+ ]"), " ").replace(Regex("\\s+"), " ").trim()
}
