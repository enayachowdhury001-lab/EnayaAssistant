# Enaya Assistant V3

Android voice assistant with Bangla/English commands.

## Supported commands
Call contacts, open common apps, camera, flashlight, Google/YouTube search, compose SMS, WhatsApp chat, battery percentage, time, date, settings.

## Important limitation
Continuous mode works while the app is visible. Android does not grant a normal third-party APK the same locked-screen/system privileges as Siri or Google Assistant. Speech recognition depends on Google Speech Services and usually internet access.
